package com.training.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import AutoHackathon.Project.DataDriver.HashMapNew;

public class HomePage {
	
	private By head = By.xpath("//*[@id='root']/section/div[1]/p");
		private String headMess = "E2E Implementation of Online Sales Portal on AWS Cloud";
		private By homePageLogin= By.name("emailId");
		private By homePagePass = By.name("password");
		 

	public  WebDriver oDriver;
	public ExtentReports oExtentReports;
	public ExtentTest oExtendTest;
	public HashMapNew dictionary;
	
	public HomePage(WebDriver oDriver,ExtentReports oExtentReports,ExtentTest oExtendTest,HashMapNew dictionary) {
		this.oDriver=oDriver;
		this.oExtendTest=oExtendTest;
		this.oExtentReports=oExtentReports;
		this.dictionary=dictionary;
	}

	public boolean CheckHomePage(WebDriver oDriver)
	{
		WebDriverWait expWait = new WebDriverWait(oDriver,20);
		WebElement e = expWait.until(ExpectedConditions.visibilityOfElementLocated(head));
		
		if(e.findElement(head).isDisplayed()) {
			oExtendTest.log(LogStatus.PASS, "Home Page is displayed");
		}
		else {
			oExtendTest.log(LogStatus.FAIL, "Home Page is not displayed");
			return false;
		}
		
		return true;
		
	}
	
	
	
	
	
	}


