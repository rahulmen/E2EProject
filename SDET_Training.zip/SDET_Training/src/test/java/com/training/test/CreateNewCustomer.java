package com.training.test;

public class CreateNewCustomer {

}
